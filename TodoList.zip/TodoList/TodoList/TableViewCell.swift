//
//  TableViewCell.swift
//  TodoList
//
//  Created by Basma Alqethami on 08/03/1443 AH.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var Title: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var notes: UILabel!
}
